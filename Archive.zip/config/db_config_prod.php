<?php
class DB_CONFIG
{
  const DB_NAME = 'id2126213_cdc';
  const DB_UN = 'id2126213_root';
  const DB_PWD = 'iuxEwMUH6yqm';
  const DB_HOST = 'localhost';
}