<?php
class DB_CONFIG
{
  const DB_NAME = 'cdc1';
  const DB_UN = 'root';
  const DB_PWD = 'root';
  const DB_HOST = 'localhost';
}