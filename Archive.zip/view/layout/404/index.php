<section>
Not found
<?= ($_GET["id"]) ? $_GET["p"]." ".$_GET["id"] : "h"; ?>
</section>