<div class="alert alert-danger">
  Le message n'a pas pu être envoyé
</div> 