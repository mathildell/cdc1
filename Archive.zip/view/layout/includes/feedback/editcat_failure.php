<div class="alert alert-danger">
  La catégorie n'a pas pu être éditée
</div> 