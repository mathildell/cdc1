<div class="alert alert-danger">
  Il y a eu un échec
</div> 