<div class="alert alert-danger">
  L'oeuvre n'a pas pu être créée
</div> 