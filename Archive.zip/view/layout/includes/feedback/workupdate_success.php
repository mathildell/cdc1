<div class="alert alert-success">
  L'oeuvre a été éditée avec succès
</div> 