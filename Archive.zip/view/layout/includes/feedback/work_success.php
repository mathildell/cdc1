<div class="alert alert-success">
  L'oeuvre a été créée avec succès
</div> 