<div class="alert alert-success">
  La note a bien été attribuée
</div> 