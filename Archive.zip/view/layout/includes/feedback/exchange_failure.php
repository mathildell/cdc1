<div class="alert alert-danger">
  Les échanges n'ont pas pu être modifiés
</div> 