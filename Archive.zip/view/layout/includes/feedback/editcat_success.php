<div class="alert alert-success">
  La catégorie a été éditée avec succès
</div> 