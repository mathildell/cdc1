<div class="alert alert-success">
  L'oeuvre a été supprimée avec succès
</div> 