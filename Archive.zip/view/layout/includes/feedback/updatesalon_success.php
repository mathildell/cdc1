<div class="alert alert-success">
  Le salon a été modifié avec succès
</div> 