<div class="alert alert-success">
  Le salon a bien été créé
</div> 