<div class="alert alert-danger">
  La note n'a pas pu être attribuée
</div> 