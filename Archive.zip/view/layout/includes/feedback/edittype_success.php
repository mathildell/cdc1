<div class="alert alert-success">
  Le type a été édité avec succès
</div> 