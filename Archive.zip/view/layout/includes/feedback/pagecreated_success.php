<div class="alert alert-success">
  La page a bien été créée
</div> 