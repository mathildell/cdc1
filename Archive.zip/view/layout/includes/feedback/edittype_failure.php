<div class="alert alert-danger">
  Le type n'a pas pu être édité
</div> 