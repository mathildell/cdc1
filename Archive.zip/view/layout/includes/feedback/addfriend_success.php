<div class="alert alert-success">
  L'ami a bien été ajouté
</div> 