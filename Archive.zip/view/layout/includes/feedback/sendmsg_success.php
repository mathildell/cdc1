<div class="alert alert-success">
  Le message a bien été envoyé
</div> 