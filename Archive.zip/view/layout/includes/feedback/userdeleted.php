<div class="alert alert-success">
  Le profil a été supprimé avec succès
</div> 