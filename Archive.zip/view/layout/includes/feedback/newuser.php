<div class="alert alert-success">
  Un nouvel utilisateur a bien été créé<br/>
  Au cas où le mail ne soit pas reçu, le mot de passe temporaire est: <b><?= $_SESSION['pwd_temp']; ?></b>
</div> 