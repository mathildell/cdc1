<div class="alert alert-success">
  Les échanges ont bien été modifiés
</div> 