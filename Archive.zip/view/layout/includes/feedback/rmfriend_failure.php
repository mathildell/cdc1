<div class="alert alert-danger">
  L'ami n'a pas pu être supprimé
</div> 