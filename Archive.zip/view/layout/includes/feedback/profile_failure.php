<div class="alert alert-danger">
  Le profil n'a pas pu être modifié
</div> 