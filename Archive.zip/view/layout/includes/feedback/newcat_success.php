<div class="alert alert-success">
  La catégorie a bien été créée
</div> 