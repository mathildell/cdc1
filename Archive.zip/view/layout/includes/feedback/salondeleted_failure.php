<div class="alert alert-danger">
  Le salon n'a pas pu être supprimé
</div> 