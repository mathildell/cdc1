<div class="alert alert-success">
  Le profil a été édité avec succès
</div> 