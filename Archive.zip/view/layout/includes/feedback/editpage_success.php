<div class="alert alert-success">
  La page a été éditée avec succès
</div> 