<div class="alert alert-danger">
  Vous n'êtes pas authorisé à acceder à cette page
</div> 