<div class="alert alert-danger">
  La page n'a pas pu être éditée
</div> 