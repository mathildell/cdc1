<div class="alert alert-success">
  Le type a été supprimé avec succès
</div> 