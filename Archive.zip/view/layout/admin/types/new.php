<form class="form" method="post" action="<?= $root ?>/processes/newtype">
<div class="row">
  <div class="col-sm-6">
    <div class="form-group">
      <label for="name">Name:</label>
      <input class="form-control" id="name" type="text" name="name">
    </div>
  </div>
  <div class="col-sm-6">
    <div class="form-group">
    </div>
  </div>
</div>
<button type="submit" class="btn btn-primary">Créer</button>
</form>